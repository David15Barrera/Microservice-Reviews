rootProject.name = "reviewsService"
